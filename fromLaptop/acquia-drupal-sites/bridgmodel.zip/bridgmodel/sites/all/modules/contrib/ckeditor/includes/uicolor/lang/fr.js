﻿/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'fr', {
	title: 'UI Sélecteur de couleur',
	preview: 'Aperçu',
	config: 'Collez cette chaîne de caractères dans votre fichier config.js',
	predefined: 'Palettes de couleurs prédéfinies'
});
