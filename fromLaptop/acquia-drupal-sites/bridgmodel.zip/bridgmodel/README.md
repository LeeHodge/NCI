# NCI Drupal Core
The base Drupal installation for a NCI multisite configuration.

Installation:
1. You must setup separate directories for each site under the sites folder.
2. You must configure sites.php (refer to example.sites.php).
3. Within the sites subdirectory, use git to add a submodule.
4. After creating a git submodule, add the Git repo for the site folder.
